import boto3
import json

def handler(event, context):
    # Your code goes here!
    client = boto3.client("dynamodb")

    selection = []
    for item in event["selection"]:
        it=dict()
        it["S"]=item
        selection.append(it)
    price = []
    for item in event["price"]:
        it=dict()
        it["S"]=item
        price.append(it)
    size = []
    for item in event["size"]:
        it=dict()
        it["S"]=item
        size.append(it)

    
    try:
        client.put_item(TableName="pizzashopmenu", Item={"menu_id":{"S":event["menu_id"]}, "store_name": {"S":event["store_name"]}, "selection":{"L": selection}, "size":{"L":size}, "price":{"L":price}, "store_hours":{"L":event["store_hours"]}})
    except Exception,e:
        return 400, e
    return 200, "OK"