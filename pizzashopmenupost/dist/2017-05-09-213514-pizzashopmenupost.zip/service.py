import boto3

def handler(event, context):
    # Your code goes here!
    client = boto3.client("dynamodb")
    
    try:
        client.put_item(TableName="pizzashopmenu", Item=event)
    except:
        return 400
    
    return 200, "OK"