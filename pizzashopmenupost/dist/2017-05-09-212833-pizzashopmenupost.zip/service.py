import boto3

def handler(event, context):
    # Your code goes here!
    client = boto3.client("dynamodb")
    for item in event:
        print item
    # try:
    #     client.put_item(TableName="pizzashopmenu", Item=)
    # except:
    