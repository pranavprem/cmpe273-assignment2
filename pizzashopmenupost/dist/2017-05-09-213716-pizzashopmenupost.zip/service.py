import boto3

def handler(event, context):
    # Your code goes here!
    client = boto3.client("dynamodb")
    
    try:
        client.put_item(TableName="pizzashopmenu", Item=event)
    except Exception,e:
        return 400, e
    
    return 200, "OK"