import boto3
import json

def handler(event, context):
    # Your code goes here!
    client = boto3.client("dynamodb")
    
    try:
        client.put_item(TableName="pizzashopmenu", Item={"menu_id":{"S":event["menu_id"]}, "store_name":{"S":event["store_name"]}, "selection":{"L": event["selection"]},"size":{"L":event["size"]},"price":{"L":event["price"]},"store_hours":{"L":event["store_hours"]}})
    except Exception,e:
        return 400, e
    
    return 200, "OK"