import boto3
import json

def handler(event, context):
    # Your code goes here!
    client = boto3.client("dynamodb")
    return event["menu_id"]
    # try:
    #     client.put_item(TableName="pizzashopmenu", Item=event)
    # except Exception,e:
    #     return 400, e
    
    # return 200, "OK"