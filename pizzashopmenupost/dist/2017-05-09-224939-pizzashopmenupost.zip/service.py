import boto3
import json

def handler(event, context):
    # Your code goes here!
    client = boto3.client("dynamodb")

    selection = []
    for item in event["selection"]:
        it=dict()
        it["S"]=item
        selection.append(it)
    price = []
    for item in event["price"]:
        it=dict()
        it["S"]=item
        price.append(it)
    size = []
    for item in event["size"]:
        it=dict()
        it["S"]=item
        size.append(it)

    store_hours={}
    for item in event["store_hours"]:
        it=dict()
        it["S"] = event["store_hours"][item]
        store_hours[item] = it
    
    try:
        client.put_item(TableName="pizzashopmenu", Item={"menu_id":{"S":event["menu_id"]}, "store_name": {"S":event["store_name"]}, "selection":{"SS": event["selection"]}, "size":{"SS":event["size"]}, "price":{"NS":event["price"]}, "store_hours":{"M":store_hours}})
    except Exception,e:
        return 400, e
    return 200, "OK"